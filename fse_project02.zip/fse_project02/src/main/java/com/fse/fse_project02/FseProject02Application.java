package com.fse.fse_project02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FseProject02Application {

	public static void main(String[] args) {
		SpringApplication.run(FseProject02Application.class, args);
	}

}
