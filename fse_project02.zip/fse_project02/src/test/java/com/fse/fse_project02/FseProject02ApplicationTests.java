package com.fse.fse_project02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FseProject02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
