package com.dbook.book.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dbook.book.entity.Book;
import com.dbook.book.entity.BuyBook;
import com.dbook.book.repository.BookRepository;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.Arrays;
import java.util.List;

@Service
public class BookService {
    @Autowired
    private BookRepository repository;
    @Autowired
	private JavaMailSender javaMailSender;
    @Autowired
	private RestTemplate restTemplate;

    public Book saveBook(Book book) {
        return repository.save(book);
    }

    public List<Book> saveBooks(List<Book> books) {
        return repository.saveAll(books);
    }

    public List<Book> getBooks() {
        return repository.findAll();
    }

    public Book getBookById(int id) {
        return repository.findById(id).orElse(null);
    }

    public Book getBookByName(String name) {
        return repository.findByTitle(name);
    }

    public String deleteBook(int id) {
        repository.deleteById(id);
        return "Book removed !! " + id;
    }
    public Book getBookSearchDetails(String category, String author, int price,String publisher) {
		return repository.findByCategoryAndAuhtorAndPriceAndPublisher(category, author,  price, publisher);

	}

//    @GetMapping("/students") 
//    public List<Object> getStudents() {
//    	Object[] objects = restTemplate.getForObject("http://student-microservice/students", Object[].class);
//    	return Arrays.asList(objects);
//    }
    
    public Book updateBook(Book book) {
        Book existingBook = repository.findById(book.getId()).orElse(null);
        // 1 if author block 
        
        //1.1 getActive_status true who have purchased book send notification to reader 
        // this book is unavailable
        
        // 1.2 book will show not search results
        
        String statuscheck="true";
        if(statuscheck=="false")
        {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setTo("21rajakumar21@gmail.com");

            msg.setSubject("Testing from Spring Boot");
            msg.setText("Hello World \n Spring Boot Email");

            javaMailSender.send(msg);

        }
        
        
        BuyBook response =
                restTemplate.getForObject(
                        "http://localhost:9053/api/v1/purchasedBooks",
                        BuyBook.class);

        List<BuyBook> employees = (List<BuyBook>) response;

        employees.forEach(System.out::println);
        
//        ResponseEntity<List<Book>> response =
//                restTemplate.exchange(
//                        "http://localhost:9053/api/v1/purchasedBooks",
//                        HttpMethod.GET,
//                        null,
//                        new ParameterizedTypeReference<List<Book>>() {
//                        });
//
//        List<Book> employees = response.getBody();
//
//        assert employees != null;
//        employees.forEach(System.out::println);

       // return employees;
        
        
        
        
       
//        Object[] objects = restTemplate.getForObject("http://localhost:9053/api/v1/purchasedBooks", Object[].class);
//        List l1=Arrays.asList(objects);

        System.out.println("employees=====>"+employees);
        System.out.println("l1=====>"+employees.toString());
       
        

        existingBook.setTitle(book.getTitle());
        existingBook.setCategory(book.getCategory());
        existingBook.setAuhtor(book.getAuhtor());
        existingBook.setAuhtorid(book.getAuhtorid());
        existingBook.setPublisher(book.getPublisher());
        existingBook.setPublished_date(book.getPublished_date());
        existingBook.setChapter(book.getChapter());
        existingBook.setActive_status(book.getActive_status());
        existingBook.setPrice(book.getPrice());
        return repository.save(existingBook);
    }


}
