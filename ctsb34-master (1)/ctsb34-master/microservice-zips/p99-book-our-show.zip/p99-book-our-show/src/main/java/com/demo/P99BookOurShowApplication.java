package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P99BookOurShowApplication {

	public static void main(String[] args) {
		SpringApplication.run(P99BookOurShowApplication.class, args);
	}

}
