package com.fse.fse_project01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FseProject01Application {

	public static void main(String[] args) {
		SpringApplication.run(FseProject01Application.class, args);
	}

}
