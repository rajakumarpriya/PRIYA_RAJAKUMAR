package com.demo.api;

public interface MessageConverter {

	public void translate(String message);
	
}
